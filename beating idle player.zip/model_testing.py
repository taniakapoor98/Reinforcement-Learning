# test.py
import matplotlib.pyplot as plt
from stable_baselines3 import PPO
from py4j.java_gateway import JavaGateway
from stable_baselines3.common.evaluation import evaluate_policy

from StreetFighter_tk import StreetFighterEnv  # Import your environment class

# Setup the game and environment
gateway = JavaGateway()
game_instance = gateway.entry_point.getGame()
game_instance.setRenderingEnabled(True)
env = StreetFighterEnv(game=game_instance)
print('Environment created for testing.')

# Load the trained model
model = PPO.load("ppo_street_fighter")
env.start_game_auto()
# Testing
num_test_episodes = 10  # Number of episodes for testing
testing_rewards = []
print('Testing started...')
for episode in range(num_test_episodes):
    obs, _ = env.reset()  # Reset environment
    total_reward = 0
    done = False
    while not done:
        action, _ = model.predict(obs, deterministic=True)
        obs, reward, done, info, _ = env.step(int(action))  # Ensure action is an integer
        total_reward += reward
    testing_rewards.append(total_reward)
    print(f"Test Episode {episode + 1}: Total Reward = {total_reward}")

mean_reward, std_reward = evaluate_policy(model, env, n_eval_episodes=10)
print(f"Mean reward: {mean_reward}, Std reward: {std_reward}")

# Plotting testing results
plt.figure(figsize=(8, 5))
plt.plot(testing_rewards, label='Total Reward (Testing)', marker='o', color='green')
plt.title('Testing Rewards per Episode')
plt.xlabel('Episode')
plt.ylabel('Total Reward')
plt.grid()
plt.legend()
plt.yticks(range(1, 21))  # Change this if you need a different range
plt.savefig('testing_rewards_plot.png')
plt.show()
